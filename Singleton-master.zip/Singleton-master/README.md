# Padrões de projeto Singleton
